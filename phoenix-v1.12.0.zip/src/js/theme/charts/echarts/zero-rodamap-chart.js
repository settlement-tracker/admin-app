/* -------------------------------------------------------------------------- */
/*                             Echarts Total Sales                            */
/* -------------------------------------------------------------------------- */

const zeroRoadmapChartInit = () => {
  const { getItemFromStore } = window.phoenix.utils;
  const zeroRoadMapEl = document.querySelector('.gantt-zero-roadmap');

  if (zeroRoadMapEl) {
    const chartEl = zeroRoadMapEl.querySelector('.gantt-zero-roadmap-chart');

    window.gantt.plugins({
      tooltip: true
    });

    window.gantt.config.date_format = '%Y-%m-%d %H:%i';
    window.gantt.config.scale_height = 0;
    window.gantt.config.row_height = 36;
    window.gantt.config.bar_height = 12;
    window.gantt.config.drag_move = false;
    window.gantt.config.drag_progress = false;
    window.gantt.config.drag_resize = false;
    window.gantt.config.drag_links = false;
    window.gantt.config.details_on_dblclick = false;
    window.gantt.config.click_drag = false;

    if (getItemFromStore('phoenixIsRTL')) {
      window.gantt.config.rtl = true;
    }

    const zoomConfig = {
      levels: [
        {
          name: 'month',
          scales: [
            { unit: 'month', format: '%F, %Y' },
            { unit: 'week', format: 'Week #%W' }
          ]
        },

        {
          name: 'year',
          scales: [{ unit: 'year', step: 1, format: '%Y' }]
        },
        {
          name: 'week',
          scales: [
            {
              unit: 'week',
              step: 1,
              format: date => {
                const dateToStr = window.gantt.date.date_to_str('%d %M');
                const endDate = window.gantt.date.add(date, -6, 'day');
                const weekNum = window.gantt.date.date_to_str('%W')(date);
                return (
                  '#' +
                  weekNum +
                  ', ' +
                  dateToStr(date) +
                  ' - ' +
                  dateToStr(endDate)
                );
              }
            },
            { unit: 'day', step: 1, format: '%j %D' }
          ]
        }
      ]
    };

    gantt.ext.zoom.init(zoomConfig);
    gantt.ext.zoom.setLevel('week');
    gantt.ext.zoom.attachEvent('onAfterZoom', function (level, config) {
      document.querySelector(
        "input[value='" + config.name + "']"
      ).checked = true;
    });

    gantt.config.columns = [{ name: 'text', width: 56, resize: true }];

    gantt.templates.task_class = (start, end, task) => task.task_class;

    gantt.templates.task_cell_class = function (task, date) {
      return 'weekend';
    };

    gantt.templates.task_text = () => '';

    window.gantt.init(chartEl);
    window.gantt.parse({
      data: [
        {
          id: 1,
          text: 'Planning',
          start_date: '2019-08-01 00:00',
          duration: 3,
          progress: 1,
          task_class: 'planning'
        },
        {
          id: 2,
          text: 'Research',
          start_date: '2019-08-02 00:00',
          duration: 5,
          // parent: 1,
          progress: 0.5,
          task_class: 'research'
        },
        {
          id: 3,
          text: 'Design',
          start_date: '2019-08-02 00:00',
          duration: 10,
          // parent: 1,
          progress: 0.4,
          task_class: 'design'
        },
        {
          id: 4,
          text: 'Review',
          start_date: '2019-08-05 00:00',
          duration: 5,
          // parent: 1,
          progress: 0.8,
          task_class: 'review'
        },
        {
          id: 5,
          text: 'Develop',
          start_date: '2019-08-06 00:00',
          duration: 10,
          // parent: 1,
          progress: 0.3,
          open: true,
          task_class: 'develop'
        },
        {
          id: 6,
          text: 'Review II',
          start_date: '2019-08-10 00:00',
          duration: 4,
          // parent: 4,
          progress: 0.02,
          task_class: 'review-2'
        }
      ],
      links: [
        { id: 1, source: 1, target: 2, type: '0' },
        { id: 2, source: 1, target: 3, type: '0' },
        { id: 3, source: 3, target: 4, type: '0' },
        { id: 4, source: 6, target: 5, type: '3' }
      ]
    });

    const scaleRadios = zeroRoadMapEl.querySelectorAll('input[name=scaleView]');

    const progressCheck = zeroRoadMapEl.querySelector('[data-gantt-progress]');
    const linksCheck = zeroRoadMapEl.querySelector('[data-gantt-links]');

    scaleRadios.forEach(item => {
      item.addEventListener('click', e => {
        window.gantt.ext.zoom.setLevel(e.target.value);
      });
    });

    linksCheck.addEventListener('change', e => {
      window.gantt.config.show_links = e.target.checked;
      window.gantt.init(chartEl);
    });

    progressCheck.addEventListener('change', e => {
      window.gantt.config.show_progress = e.target.checked;
      window.gantt.init(chartEl);
    });
  }
};

export default zeroRoadmapChartInit;
