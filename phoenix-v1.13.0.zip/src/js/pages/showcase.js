import showcaseParallaxInit from '../theme/showcase-parallax';

const { docReady } = window.phoenix.utils;

docReady(showcaseParallaxInit);
