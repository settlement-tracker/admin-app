import appCalendarInit from '../theme/calendar/app-calendar';

const { docReady } = window.phoenix.utils;

docReady(appCalendarInit);
